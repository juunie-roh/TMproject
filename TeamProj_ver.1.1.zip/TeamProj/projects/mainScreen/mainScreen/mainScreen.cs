﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace mainScreen
{

    public partial class mainScreen : MetroForm
    {
        private map_api.vaccine_search vaccineLocation;
        private WindowsFormsApp1.Form1 covidStatus;
        private QuarterlyPlan2.main quarterlyPlan;
        private COVID_19_Data.Form1 covidData;

        public mainScreen()
        {
            InitializeComponent();
        }

        /*
         * 폼 속성 - 창 스타일 - MinimizeBox & MaximizeBox - false 설정
         */

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            panel7.Width += 3; //길어지는 panel
            if (panel7.Width >= 440)
            {
                timer1.Stop();
                this.Size = new Size(390, 500);
                panel6.Visible = false; //라인 panel
                panel7.Visible = false; // 길어지는 panel
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vaccineLocation = new map_api.vaccine_search();
            // 폼 속성 - 레이아웃 - StartLocation - Manual 로 변경 후 아래 코드 실행하면 폼 실행 위치 지정 가능
            vaccineLocation.Location = new Point(this.Location.X + 390, this.Location.Y);
            vaccineLocation.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            covidStatus = new WindowsFormsApp1.Form1();
            covidStatus.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            quarterlyPlan = new QuarterlyPlan2.main();
            quarterlyPlan.Location = new Point(this.Location.X + 390, this.Location.Y);
            quarterlyPlan.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            covidData = new COVID_19_Data.Form1();
            covidData.Show();
        }

        private void mainScreen_Resize(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
    }
}