﻿
namespace QuarterlyPlan2
{
    partial class main
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.orderbtn = new System.Windows.Forms.Button();
            this.planbtn = new System.Windows.Forms.Button();
            this.analbtn = new System.Windows.Forms.Button();
            this.videobtn = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel3 = new System.Windows.Forms.FlowLayoutPanel();
            this.flowLayoutPanel4 = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel5 = new System.Windows.Forms.FlowLayoutPanel();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.flowLayoutPanel6 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.flowLayoutPanel1.SuspendLayout();
            this.flowLayoutPanel2.SuspendLayout();
            this.flowLayoutPanel4.SuspendLayout();
            this.flowLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // orderbtn
            // 
            this.orderbtn.BackColor = System.Drawing.Color.LightBlue;
            this.orderbtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.orderbtn.FlatAppearance.BorderSize = 0;
            this.orderbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.orderbtn.Font = new System.Drawing.Font("나눔스퀘어", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.orderbtn.Location = new System.Drawing.Point(51, 210);
            this.orderbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.orderbtn.Name = "orderbtn";
            this.orderbtn.Size = new System.Drawing.Size(293, 58);
            this.orderbtn.TabIndex = 0;
            this.orderbtn.Text = "분기별 접종 순서";
            this.orderbtn.UseVisualStyleBackColor = false;
            this.orderbtn.Click += new System.EventHandler(this.orderbtn_Click);
            // 
            // planbtn
            // 
            this.planbtn.BackColor = System.Drawing.Color.LightBlue;
            this.planbtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.planbtn.FlatAppearance.BorderSize = 0;
            this.planbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.planbtn.Font = new System.Drawing.Font("나눔스퀘어", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.planbtn.Location = new System.Drawing.Point(51, 284);
            this.planbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.planbtn.Name = "planbtn";
            this.planbtn.Size = new System.Drawing.Size(293, 58);
            this.planbtn.TabIndex = 1;
            this.planbtn.Text = "5월 이후 추진 계획";
            this.planbtn.UseVisualStyleBackColor = false;
            this.planbtn.Click += new System.EventHandler(this.planbtn_Click);
            // 
            // analbtn
            // 
            this.analbtn.BackColor = System.Drawing.Color.LightBlue;
            this.analbtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.analbtn.FlatAppearance.BorderSize = 0;
            this.analbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.analbtn.Font = new System.Drawing.Font("나눔스퀘어", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.analbtn.Location = new System.Drawing.Point(51, 359);
            this.analbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.analbtn.Name = "analbtn";
            this.analbtn.Size = new System.Drawing.Size(293, 58);
            this.analbtn.TabIndex = 2;
            this.analbtn.Text = "1분기 예방접종 분석";
            this.analbtn.UseVisualStyleBackColor = false;
            this.analbtn.Click += new System.EventHandler(this.analbtn_Click);
            // 
            // videobtn
            // 
            this.videobtn.BackColor = System.Drawing.Color.LightBlue;
            this.videobtn.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.videobtn.FlatAppearance.BorderSize = 0;
            this.videobtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.videobtn.Font = new System.Drawing.Font("나눔스퀘어", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.videobtn.Location = new System.Drawing.Point(51, 433);
            this.videobtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.videobtn.Name = "videobtn";
            this.videobtn.Size = new System.Drawing.Size(293, 58);
            this.videobtn.TabIndex = 3;
            this.videobtn.Text = "예방접종 참조영상";
            this.videobtn.UseVisualStyleBackColor = false;
            this.videobtn.Click += new System.EventHandler(this.videobtn_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.flowLayoutPanel1.Controls.Add(this.textBox1);
            this.flowLayoutPanel1.Controls.Add(this.flowLayoutPanel2);
            this.flowLayoutPanel1.Controls.Add(this.flowLayoutPanel3);
            this.flowLayoutPanel1.Controls.Add(this.flowLayoutPanel4);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(21, 75);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(351, 72);
            this.flowLayoutPanel1.TabIndex = 4;
            // 
            // textBox1
            // 
            this.textBox1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("나눔스퀘어라운드 ExtraBold", 16.2F, System.Drawing.FontStyle.Bold);
            this.textBox1.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox1.Location = new System.Drawing.Point(15, 23);
            this.textBox1.Margin = new System.Windows.Forms.Padding(15, 23, 22, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(336, 31);
            this.textBox1.TabIndex = 3;
            this.textBox1.Text = "분기별 계획 및 영상";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.flowLayoutPanel2.Controls.Add(this.textBox2);
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(3, 66);
            this.flowLayoutPanel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(351, 72);
            this.flowLayoutPanel2.TabIndex = 5;
            // 
            // textBox2
            // 
            this.textBox2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("나눔스퀘어라운드 ExtraBold", 16.2F, System.Drawing.FontStyle.Bold);
            this.textBox2.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox2.Location = new System.Drawing.Point(15, 23);
            this.textBox2.Margin = new System.Windows.Forms.Padding(15, 23, 22, 10);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(336, 31);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "분기별 계획 및 영상";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // flowLayoutPanel3
            // 
            this.flowLayoutPanel3.Location = new System.Drawing.Point(3, 143);
            this.flowLayoutPanel3.Name = "flowLayoutPanel3";
            this.flowLayoutPanel3.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel3.TabIndex = 6;
            // 
            // flowLayoutPanel4
            // 
            this.flowLayoutPanel4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.flowLayoutPanel4.Controls.Add(this.textBox3);
            this.flowLayoutPanel4.Controls.Add(this.flowLayoutPanel5);
            this.flowLayoutPanel4.Controls.Add(this.flowLayoutPanel6);
            this.flowLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel4.Location = new System.Drawing.Point(3, 248);
            this.flowLayoutPanel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel4.Name = "flowLayoutPanel4";
            this.flowLayoutPanel4.Size = new System.Drawing.Size(351, 72);
            this.flowLayoutPanel4.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox3.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Font = new System.Drawing.Font("나눔스퀘어라운드 ExtraBold", 16.2F, System.Drawing.FontStyle.Bold);
            this.textBox3.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox3.Location = new System.Drawing.Point(15, 23);
            this.textBox3.Margin = new System.Windows.Forms.Padding(15, 23, 22, 10);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(336, 31);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "분기별 계획 및 영상";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // flowLayoutPanel5
            // 
            this.flowLayoutPanel5.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.flowLayoutPanel5.Controls.Add(this.textBox4);
            this.flowLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.flowLayoutPanel5.Location = new System.Drawing.Point(3, 66);
            this.flowLayoutPanel5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.flowLayoutPanel5.Name = "flowLayoutPanel5";
            this.flowLayoutPanel5.Size = new System.Drawing.Size(351, 72);
            this.flowLayoutPanel5.TabIndex = 5;
            // 
            // textBox4
            // 
            this.textBox4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.textBox4.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.textBox4.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox4.Font = new System.Drawing.Font("나눔스퀘어라운드 ExtraBold", 16.2F, System.Drawing.FontStyle.Bold);
            this.textBox4.ForeColor = System.Drawing.SystemColors.Window;
            this.textBox4.Location = new System.Drawing.Point(15, 23);
            this.textBox4.Margin = new System.Windows.Forms.Padding(15, 23, 22, 10);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(336, 31);
            this.textBox4.TabIndex = 3;
            this.textBox4.Text = "분기별 계획 및 영상";
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // flowLayoutPanel6
            // 
            this.flowLayoutPanel6.Location = new System.Drawing.Point(3, 143);
            this.flowLayoutPanel6.Name = "flowLayoutPanel6";
            this.flowLayoutPanel6.Size = new System.Drawing.Size(200, 100);
            this.flowLayoutPanel6.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Location = new System.Drawing.Point(0, 566);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(404, 55);
            this.panel1.TabIndex = 5;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 625);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.videobtn);
            this.Controls.Add(this.analbtn);
            this.Controls.Add(this.planbtn);
            this.Controls.Add(this.orderbtn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Movable = false;
            this.Name = "main";
            this.Padding = new System.Windows.Forms.Padding(21, 75, 21, 20);
            this.Resizable = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.flowLayoutPanel1.ResumeLayout(false);
            this.flowLayoutPanel1.PerformLayout();
            this.flowLayoutPanel2.ResumeLayout(false);
            this.flowLayoutPanel2.PerformLayout();
            this.flowLayoutPanel4.ResumeLayout(false);
            this.flowLayoutPanel4.PerformLayout();
            this.flowLayoutPanel5.ResumeLayout(false);
            this.flowLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button orderbtn;
        private System.Windows.Forms.Button planbtn;
        private System.Windows.Forms.Button analbtn;
        private System.Windows.Forms.Button videobtn;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel6;
        private System.Windows.Forms.Panel panel1;
    }
}

