﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;

namespace mainScreen
{
    public partial class mainScreen : MetroForm
    {
        private Size defaultSize = new Size(390, 500);

        private map_api.vaccine_search vaccineLocation;
        private WindowsFormsApp1.Form1 covidStatus;
        private QuarterlyPlan2.main quarterlyPlan;
        private COVID_19_Data.Menu4 covidData;

        public mainScreen()
        {
            InitializeComponent();
        }

        /*
         * 폼 속성 - 창 스타일 - MinimizeBox & MaximizeBox - false 설정
         */

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            panel7.Width += 3; //길어지는 panel
            if (panel7.Width >= 440)
            {
                timer1.Stop();
                this.Size = defaultSize;
                panel6.Visible = false; //라인 panel
                panel7.Visible = false; // 길어지는 panel
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vaccineLocation = new map_api.vaccine_search();
            this.Size = new Size(defaultSize.Width + vaccineLocation.Width, defaultSize.Height);
            vaccineLocation.Location = new Point(this.Location.X + defaultSize.Width, this.Location.Y);
            vaccineLocation.ShowDialog();
            MetroForm menu1 = (MetroForm)Application.OpenForms["vaccine_search"];
            if (menu1 == null)
                this.Size = defaultSize;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            covidStatus = new WindowsFormsApp1.Form1();
            this.Size = new Size(defaultSize.Width + covidStatus.Width, covidStatus.Height);
            covidStatus.Location = new Point(this.Location.X + defaultSize.Width, this.Location.Y);
            covidStatus.ShowDialog();
            Form menu2 = Application.OpenForms["Form1"];
            if (menu2 == null)
                this.Size = defaultSize;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            quarterlyPlan = new QuarterlyPlan2.main();
            this.Size = new Size(defaultSize.Width + quarterlyPlan.Width, defaultSize.Height);
            quarterlyPlan.Location = new Point(this.Location.X + defaultSize.Width, this.Location.Y);
            quarterlyPlan.ShowDialog();
            MetroForm menu3 = (MetroForm)Application.OpenForms["main"];
            if (menu3 == null)
                this.Size = defaultSize;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            covidData = new COVID_19_Data.Menu4();
            this.Size = new Size(defaultSize.Width + covidData.Width, defaultSize.Height);
            covidData.Location = new Point(this.Location.X + defaultSize.Width, this.Location.Y);
            covidData.ShowDialog();
            MetroForm menu4 = (MetroForm)Application.OpenForms["Menu4"];
            if (menu4 == null)
                this.Size = defaultSize;
        }

        private void mainScreen_Resize(object sender, EventArgs e)
        {
            this.CenterToScreen();
        }
    }
}